import requests
import json

def get_api_data():

    url = "https://cmdb.eltex.loc/cmdbuild/services/rest/v3/classes/Server/cards?filter=%7B%22attribute%22%3A%7B%22and%22%3A%5B%7B%22simple%22%3A%7B%22value%22%3A%5Btrue%5D%2C%22operator%22%3A%22equal%22%2C%22attribute%22%3A%22DeployOCSAgent%22%7D%7D%5D%7D%7D"

    payload = {}
    files={}
    headers = {
    'Authorization': 'Basic YWRtaW46YWRtaW4='
    }

    response = requests.request("GET", url, headers=headers, data=payload, files=files)
    data = json.loads(response.text)['data']

    template = {
        "all": {
            "hosts": []
        },
        "_meta": {
            "hostvars": {}
        }
    }

    for item in data:
        template['all']['hosts'].append(item['Hostname'])
        template['_meta']['hostvars'][item['Hostname']] = {}

    return template

result = get_api_data()

print(result)