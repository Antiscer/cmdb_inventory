from ansible.plugins.inventory import BaseInventoryPlugin
import json
import requests

ANSIBLE_METADATA = {
    'metadata_version': '1.0.1',
    'status': ['preview'],
    'supported_by': 'Eltex OT'
}

DOCUMENTATION = '''
---
module: example_hosts
plugin_type: inventory
short_description: An example Ansible Inventory Plugin
version_added: "2.9.13"
description:
    - "Сбор инвентаря с системы cmdbuild (cmdb.eltex.loc)"
options:
author:
    - Sergey Antonov
'''


class InventoryModule(BaseInventoryPlugin):
    """Плагин для получения инвентаря из CMDBuild."""

    NAME = 'cmdbuild.inventory.servers'

    def verify_file(self, path):
        """Здесь мы можем проводить проверку корректности данных

        Parameters:
            path:AnyStr The path to the file that needs to be verified

        Returns:
            bool True if the file is valid, else False
        """
        # Unused, always return True
        return True
    
    def _get_raw_host_data(self):
        """Получаем сырые данные по запросу из API CMDBuild

        Returns:
            Возвращает табличные данные содержащие список хостов
        """

        url = "https://cmdb.eltex.loc/cmdbuild/services/rest/v3/classes/Server/cards?filter=%7B%22attribute%22%3A%7B%22and%22%3A%5B%7B%22simple%22%3A%7B%22value%22%3A%5Btrue%5D%2C%22operator%22%3A%22equal%22%2C%22attribute%22%3A%22OCSDeploy%22%7D%7D%5D%7D%7D"

        payload = {}
        files={}
        headers = {
        'Authorization': 'Basic YXBpOjZraFZ6UVQ2IUZVZDcj'
        }

        response = requests.request("GET", url, headers=headers, data=payload, files=files)
        data = json.loads(response.text)['data']
        
        template = {
            "all": {
                "hosts": []
            },
            "_meta": {
                "hostvars": {}
            }
        }
        
        for item in data:
            template['all']['hosts'].append(item['Hostname'])
            template['_meta']['hostvars'][item['Hostname']] = {}
        
        return template
        
        # return {
        #     "all": {
        #         "hosts": ["10.13.10.85", "172.16.5.29"]
        #     },
        #     "_meta": {
        #         "hostvars": {
        #             "10.13.10.85": {
        #                 "ansible_user": "ansible"
        #             },
        #             "172.16.5.29": {
        #                 "ansible_user": "ansible"
        #             }
        #         }
        #     }
        # }

    def parse(self, inventory, *args, **kwargs):
            """Parse and populate the inventory with data about hosts.

            Parameters:
                inventory The inventory to populate

            We ignore the other parameters in the future signature, as we will
            not use them.

            Returns:
                None
            """
            # The following invocation supports Python 2 in case we are
            # still relying on it. Use the more convenient, pure Python 3 syntax
            # if you don't need it.
            super(InventoryModule, self).parse(inventory, *args, **kwargs)

            raw_data = self._get_raw_host_data()
            _meta = raw_data.pop('_meta')
            for group_name, group_data in raw_data.items():
                for host_name in group_data['hosts']:
                    self.inventory.add_host(host_name)
                    for var_key, var_val in _meta['hostvars'][host_name].items():
                        self.inventory.set_variable(host_name, var_key, var_val)